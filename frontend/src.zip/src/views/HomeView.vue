<script setup>
import { ref, onMounted } from 'vue'
import Navbar from '@/components/layouts/Navbar.vue'
import api    from '@/services/api.js'

const userName        = ref('')
const totalBooks      = ref(0)
const pendingRequests = ref(0)
const successfulTrades= ref(0)
const incoming        = ref([])
const loading         = ref(true)
const error           = ref(null)

function statusClass(s) {
  if (s==='accepted') return 'bg-success'
  if (s==='declined') return 'bg-danger'
  return 'bg-warning text-dark'
}

async function loadIncoming() {
  const { exchanges } = await api.getReceivedExchanges()
  incoming.value      = exchanges
  pendingRequests.value = exchanges.filter(e=>e.status==='pending').length
}

onMounted(async () => {
  try {
    const p = await api.getProfile()
    userName.value = p.data.data.username

    const { books } = await api.getMyBooks()
    totalBooks.value= books.length

    await loadIncoming()

    const { exchanges: sent } = await api.getMyExchangeRequests()
    successfulTrades.value = sent.filter(e=>e.status==='accepted').length
  } catch (e) {
    console.error(e)
    error.value = e.response?.data?.message || 'Gagal memuat data'
  } finally {
    loading.value = false
  }
})
</script>


<template>
  <Navbar />


   <div class="main-content py-4">
    <div v-if="loading" class="text-center py-5">
      <div class="spinner-border"></div>
    </div>
    <div v-else-if="error" class="alert alert-danger">
      {{ error }}
    </div>
    <div v-else>
       <div class="main-content py-4">
    <!-- 1. Greeting -->
    <h1 class="h3 mb-4">Selamat datang, {{ userName }}!</h1>

    <!-- 2. Statistik Ringkas -->
    <div class="row mb-5">
      <div class="col-md-3 mb-3" v-for="stat in [
        { title:'Total Buku', count: totalBooks },
        { title:'Request Pending', count: pendingRequests },
        { title:'Tukar Sukses', count: successfulTrades },
        { title:'Artikel', count: totalPosts }
      ]" :key="stat.title">
        <div class="card text-white bg-primary h-100">
          <div class="card-body">
            <h5 class="card-title">{{ stat.title }}</h5>
            <p class="card-text display-4">{{ stat.count }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- 3. Pencarian & Quick Actions -->
    <div class="row align-items-center mb-5">
      <div class="col-md-6">
        <input
          v-model="query"
          type="text"
          class="form-control"
          placeholder="Cari buku..."
        />
      </div>
    </div>

    <!-- 4. Request Masuk -->
    <div class="row">
      <div class="col-12 mb-4">
        <h5>Request Masuk</h5>
        <table class="table table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>Pengirim</th>
              <th>Buku Diminta</th>
              <th>Buku Ditawarkan</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="r in incomingRequests" :key="r.id">
              <td>{{ r.id }}</td>
              <td>{{ r.requester.username }}</td>
              <td>{{ r.requestedBook.title }}</td>
              <td>{{ r.offeredBook.title }}</td>
              <td>
                <span :class="['badge', statusClass(r.status)]">
                  {{ r.status }}
                </span>
              </td>
              <td>
                <button
                  v-if="r.status === 'pending'"
                  class="btn btn-sm btn-success me-2"
                  @click="respond(r.id, 'accepted')"
                >
                  Terima
                </button>
                <button
                  v-if="r.status === 'pending'"
                  class="btn btn-sm btn-danger"
                  @click="respond(r.id, 'declined')"
                >
                  Tolak
                </button>
                <span v-else class="text-muted">—</span>
              </td>
            </tr>
            <tr v-if="incomingRequests.length === 0">
              <td colspan="6" class="text-center text-muted">
                Belum ada request.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    </div>
    </div>
  </div>
</template>

<style scoped>
/* kosong, pakai Bootstrap saja */
</style>

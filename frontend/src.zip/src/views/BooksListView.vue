<!-- src/views/BookListView.vue -->
<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import Navbar   from '@/components/layouts/Navbar.vue'
import BookCard from '@/components/cards/BookCard.vue'
import api      from '@/services/api.js'

const router      = useRouter()
const books       = ref([])
const query       = ref('')
const filterGenre = ref('')
const page        = ref(1)
const perPage     = 8
const loading     = ref(true)
const error       = ref(null)

onMounted(async () => {
  try {
    const { books: list } = await api.getAllBooks()
    books.value = list.map(b => ({ ...b, coverUrl: b.imageUrl }))
  } catch (e) {
    console.error(e)
    error.value = 'Gagal memuat daftar buku.'
  } finally {
    loading.value = false
  }
})

const genres = computed(() =>
  Array.from(new Set(books.value.map(b => b.genre).filter(Boolean)))
)

const filteredBooks = computed(() =>
  books.value.filter(b =>
    b.title.toLowerCase().includes(query.value.toLowerCase()) &&
    (filterGenre.value === '' || b.genre === filterGenre.value)
  )
)

const totalPages = computed(() =>
  Math.ceil(filteredBooks.value.length / perPage)
)
const paginatedBooks = computed(() => {
  const start = (page.value - 1) * perPage
  return filteredBooks.value.slice(start, start + perPage)
})

function changePage(p) {
  if (p >= 1 && p <= totalPages.value) page.value = p
}
function goToEdit(book) {
  router.push({ name: 'book-edit', params: { id: book.id } })
}
async function confirmDelete(book) {
  if (confirm(`Hapus buku “${book.title}”?`)) {
    await api.deleteBook(book.id)
    books.value = books.value.filter(b => b.id !== book.id)
  }
}
function goToExchange(book) {
  router.push({ name: 'books-swap', query: { bookId: book.id } })
}
</script>

<template>
  <Navbar/>

  <div class="main-content py-4">
    <div v-if="loading" class="text-center py-5">
      <div class="spinner-border"></div>
    </div>
    <div v-else-if="error" class="alert alert-danger">{{ error }}</div>
    <div v-else>
      <!-- Search & Filter -->
      <div class="row mb-4 align-items-center">
        <div class="col-md-4">
          <input
            v-model="query"
            class="form-control"
            placeholder="Cari buku..."
          />
        </div>
        <div class="col-md-3">
          <select v-model="filterGenre" class="form-select">
            <option value="">Semua Genre</option>
            <option v-for="g in genres" :key="g">{{ g }}</option>
          </select>
        </div>
        <div class="col-md-5 text-end">
          <router-link to="/books/new" class="btn btn-success">
            + Posting Buku
          </router-link>
        </div>
      </div>

      <!-- Grid of BookCard -->
      <div class="row g-4">
        <div
          v-for="book in paginatedBooks"
          :key="book.id"
          class="col-sm-6 col-md-4 col-lg-3"
        >
          <BookCard
            :book="book"
            @edit="goToEdit"
            @delete="confirmDelete"
            @exchange="goToExchange"
          />
        </div>
        <div v-if="paginatedBooks.length===0" class="col-12 text-center text-muted">
          Tidak ada buku yang cocok.
        </div>
      </div>

      <!-- Pagination -->
      <nav v-if="totalPages>1" class="mt-4">
        <ul class="pagination justify-content-center">
          <li
            class="page-item"
            :class="{ disabled: page===1 }"
          >
            <button
              class="page-link"
              @click="changePage(page-1)"
              :disabled="page===1"
            >
              Previous
            </button>
          </li>
          <li
            v-for="p in totalPages"
            :key="p"
            class="page-item"
            :class="{ active: p===page }"
          >
            <button class="page-link" @click="changePage(p)">{{ p }}</button>
          </li>
          <li
            class="page-item"
            :class="{ disabled: page===totalPages }"
          >
            <button
              class="page-link"
              @click="changePage(page+1)"
              :disabled="page===totalPages"
            >
              Next
            </button>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</template>

<style scoped>
/* Bootstrap sudah cukup */
</style>

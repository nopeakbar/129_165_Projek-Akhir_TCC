<!-- src/views/ProfileView.vue -->
<script setup>
import { ref, onMounted } from 'vue'
import { useRouter }    from 'vue-router'
import Navbar           from '@/components/layouts/Navbar.vue'
import BookCard         from '@/components/cards/BookCard.vue'
import EditProfileModal from '@/components/modals/EditProfileModal.vue'
import EditPasswordModal from '@/components/modals/EditPasswordModal.vue'
import api              from '@/services/api.js'

const router    = useRouter()
const loading   = ref(true)
const error     = ref(null)
const user      = ref({ username:'', email:'', avatar_url: null })
const books     = ref([])
const history   = ref([])
const activeTab = ref('books')
const showModal = ref(false)
const showPwd  = ref(false)
const defaultAvatar = 'https://via.placeholder.com/120?text=Avatar'

function formatDate(dt) {
  return new Date(dt).toLocaleDateString('id-ID',{
    day:'numeric', month:'short', year:'numeric'
  })
}
function statusClass(s) {
  if (s==='accepted') return 'bg-success'
  if (s==='declined') return 'bg-danger'
  return 'bg-warning text-dark'
}

async function onUpdateProfile(updated) {
  await api.updateProfile(updated)
  Object.assign(user.value, updated)
  showModal.value = false
}
async function onChangePassword({ oldPassword, newPassword }) {
  await api.changePassword(oldPassword, newPassword)
  alert('Password berhasil diperbarui!')
  showPwd.value = false
}
async function confirmDelete(b) {
  if (confirm(`Hapus buku “${b.title}”?`)) {
    await api.deleteBook(b.id)
    books.value = books.value.filter(x => x.id !== b.id)
  }
}
function goToEdit(b) {
  router.push({ name:'book-edit', params:{ id: b.id } })
}

onMounted(async () => {
  try {
    const pRes = await api.getProfile()
    user.value = pRes.data.data

    const { books: myBooks }     = await api.getMyBooks()
    const { exchanges }          = await api.getMyExchangeRequests()

    books.value   = myBooks.map(b=>({ ...b, coverUrl:b.imageUrl }))
    history.value = exchanges.map(e=>({
      id: e.id,
      date: e.createdAt,
      bookRequested: e.requestedBook,
      bookOffered:   e.offeredBook,
      partner:       e.owner,
      status:        e.status
    }))
  } catch (e) {
    console.error(e)
    error.value = e.response?.data?.message || 'Gagal memuat profil.'
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <Navbar/>
  <div class="main-content py-4">
    <div v-if="loading" class="text-center py-5">
      <div class="spinner-border"></div>
    </div>
    <div v-else-if="error" class="alert alert-danger">{{ error }}</div>
    <div v-else>
      <h1 class="mb-4">Profile Saya</h1>

      <div class="row mb-5">
        <div class="col-md-4">
          <div class="card text-center p-4">
            <img
              :src="user.avatar_url||defaultAvatar"
              class="rounded-circle mb-3"
              width="120" height="120"
            />
            <h4>{{ user.username }}</h4>
            <p class="text-muted">{{ user.email }}</p>
            <button class="btn btn-outline-primary btn-sm me-2" @click="showModal=true">
              Edit Profil
            </button>
            <button class="btn btn-outline-warning btn-sm" @click="showPwd=true">
              Ganti Password
            </button>
          </div>
        </div>

        <div class="col-md-8">
          <div class="row g-3">
            <div class="col-6">
              <div class="card text-white bg-success h-100">
                <div class="card-body">
                  <h6>My Books</h6>
                  <p class="display-6">{{ books.length }}</p>
                </div>
              </div>
            </div>
            <div class="col-6">
              <div class="card text-white bg-info h-100">
                <div class="card-body">
                  <h6>Riwayat</h6>
                  <p class="display-6">{{ history.length }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <ul class="nav nav-tabs mb-3">
        <li class="nav-item">
          <button
            class="nav-link"
            :class="{ active: activeTab==='books' }"
            @click="activeTab='books'"
          >
            My Books
          </button>
        </li>
        <li class="nav-item">
          <button
            class="nav-link"
            :class="{ active: activeTab==='history' }"
            @click="activeTab='history'"
          >
            History
          </button>
        </li>
      </ul>

      <!-- My Books -->
      <section v-if="activeTab==='books'">
        <div class="row g-4">
          <div
            v-for="b in books"
            :key="b.id"
            class="col-sm-6 col-md-4 col-lg-3"
          >
            <BookCard
              :book="b"
              @edit="goToEdit(b)"
              @delete="confirmDelete(b)"
            />
          </div>
          <div v-if="books.length===0" class="col-12 text-center text-muted">
            Belum ada buku.
          </div>
        </div>
      </section>

      <!-- History -->
      <section v-else>
        <h2 class="mb-3">Riwayat Penukaran</h2>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>Tanggal</th>
                <th>Buku Diminta</th>
                <th>Buku Ditawarkan</th>
                <th>Dengan</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="h in history" :key="h.id">
                <td>{{ formatDate(h.date) }}</td>
                <td>{{ h.bookRequested.title }}</td>
                <td>{{ h.bookOffered.title }}</td>
                <td>{{ h.partner.username }}</td>
                <td>
                  <span class="badge" :class="statusClass(h.status)">
                    {{ h.status }}
                  </span>
                </td>
              </tr>
              <tr v-if="history.length===0">
                <td colspan="5" class="text-center text-muted">
                  Belum ada riwayat penukaran.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </div>

  <EditProfileModal
    :show="showModal"
    :user="user"
    @close="showModal=false"
    @save="onUpdateProfile"
  />
  <EditPasswordModal
    :show="showPwd"
    @close="showPwd=false"
    @save="onChangePassword"
  />
</template>

<style scoped>
/* pakai Bootstrap */
</style>

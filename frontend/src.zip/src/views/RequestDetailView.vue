<!-- src/views/RequestDetailView.vue -->
<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Navbar      from '@/components/layouts/Navbar.vue'
import Breadcrumb  from '@/components/commons/Breadcrumb.vue'
import api         from '@/services/api.js'

const route   = useRoute()
const router  = useRouter()
const loading = ref(true)
const request = ref(null)
const error   = ref(null)

const defaultCover  = 'https://via.placeholder.com/300x400?text=No+Cover'
const defaultAvatar = 'https://via.placeholder.com/80?text=Avatar'

function formatDate(dateStr) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('id-ID',{ day:'numeric', month:'short', year:'numeric' })
    + ' '
    + d.toLocaleTimeString('id-ID',{ hour:'2-digit', minute:'2-digit' })
}

function statusClass(s) {
  if (s==='accepted') return 'bg-success'
  if (s==='declined') return 'bg-danger'
  return 'bg-warning text-dark'
}

async function accept() {
  await api.updateExchangeStatus(request.value.id, 'accepted')
  request.value.status = 'accepted'
}
async function decline() {
  await api.updateExchangeStatus(request.value.id, 'declined')
  request.value.status = 'declined'
}
function goBack() {
  router.back()
}

onMounted(async () => {
  const id = Number(route.params.id)
  try {
    const [{ exchanges: rec }, { exchanges: sent }] = await Promise.all([
      api.getReceivedExchanges(),
      api.getMyExchangeRequests()
    ])
    const all = [...rec, ...sent]
    const found = all.find(e => e.id === id)
    if (!found) return router.replace({ name:'request-detail' })

    request.value = {
      id: found.id,
      sender: (found.requester || found.owner),
      bookRequested: {
        ...found.requestedBook,
        coverUrl: found.requestedBook.imageUrl
      },
      bookOffered: {
        ...found.offeredBook,
        coverUrl: found.offeredBook.imageUrl
      },
      message: found.messages || '',
      method: found.location ? 'meet' : 'delivery',
      location: found.location || found.address || '',
      date: found.meetingDatetime?.slice(0,10) || '',
      time: found.meetingDatetime?.slice(11,16) || '',
      created_at: found.createdAt,
      status: found.status
    }
  } catch (e) {
    console.error(e)
    error.value = 'Gagal memuat detail request.'
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <Navbar/>

  <div class="main-content py-4">
    <Breadcrumb :items="[
      { text:'Home', to:'/' },
      { text:'Requests', to:'/exchange/requests' },
      { text:'Detail Request', active:true }
    ]"/>

    <button class="btn btn-link mb-3" @click="goBack">← Kembali</button>

    <div v-if="loading" class="text-center py-5">
      <div class="spinner-border"></div>
    </div>
    <div v-else-if="error" class="alert alert-danger">{{ error }}</div>
    <div v-else-if="request">
      <h1 class="mb-4">Detail Request Penukaran</h1>

      <!-- Pengirim -->
      <div class="row align-items-center mb-4">
        <div class="col-auto text-center">
          <img
            :src="request.sender.avatarUrl||defaultAvatar"
            class="rounded-circle"
            width="80" height="80"
          />
          <p class="mt-2 mb-0"><strong>{{ request.sender.name }}</strong></p>
          <small class="text-muted">{{ request.sender.email }}</small>
        </div>
        <div class="col">
          <p>Dikirim pada: {{ formatDate(request.created_at) }}</p>
          <span class="badge" :class="statusClass(request.status)">
            {{ request.status }}
          </span>
        </div>
      </div>

      <!-- Buku Diminta -->
      <h5>Buku Diminta</h5>
      <div class="card mb-3 p-3">
        <div class="row g-3 align-items-center">
          <div class="col-auto">
            <img
              :src="request.bookRequested.coverUrl||defaultCover"
              width="100" class="rounded"
            />
          </div>
          <div class="col">
            <h6>{{ request.bookRequested.title }}</h6>
            <p class="text-muted mb-0">by {{ request.bookRequested.author }}</p>
          </div>
        </div>
      </div>

      <!-- Buku Ditawarkan -->
      <h5>Buku Ditawarkan</h5>
      <div class="card mb-3 p-3">
        <div class="row g-3 align-items-center">
          <div class="col-auto">
            <img
              :src="request.bookOffered.coverUrl||defaultCover"
              width="100" class="rounded"
            />
          </div>
          <div class="col">
            <h6>{{ request.bookOffered.title }}</h6>
            <p class="text-muted mb-0">by {{ request.bookOffered.author }}</p>
          </div>
        </div>
      </div>

      <!-- Pesan -->
      <h5>Pesan</h5>
      <p>{{ request.message }}</p>

      <!-- Metode & Jadwal -->
      <h5>Detail Pertukaran</h5>
      <p><strong>Metode:</strong> {{ request.method==='meet'?'Ketemuan':'Kirim Kurir' }}</p>
      <p><strong>{{ request.method==='meet'?'Lokasi':'Alamat' }}:</strong> {{ request.location }}</p>
      <p><strong>Waktu:</strong> {{ request.date }} {{ request.time }}</p>

      <!-- Aksi -->
      <div v-if="request.status==='pending'" class="mt-4">
        <button class="btn btn-success me-2" @click="accept">Terima</button>
        <button class="btn btn-danger" @click="decline">Tolak</button>
      </div>
    </div>

    <div v-else class="text-center text-muted py-5">
      Request tidak ditemukan.
    </div>
  </div>
</template>

<style scoped>
/* pakai Bootstrap */
</style>

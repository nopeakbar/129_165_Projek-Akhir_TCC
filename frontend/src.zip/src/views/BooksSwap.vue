<!-- src/views/RequestDetailView.vue -->
<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Navbar from '@/components/layouts/Navbar.vue'
import Breadcrumb from '@/components/commons/Breadcrumb.vue'
import api from '@/services/api.js'

const route  = useRoute()
const router = useRouter()
const request = ref(null)
const loading = ref(true)

const defaultCover  = 'https://via.placeholder.com/300x400?text=No+Cover'
const defaultAvatar = 'https://via.placeholder.com/80?text=Avatar'

function formatDate(dateStr) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('id-ID',{ day: 'numeric', month: 'short', year: 'numeric' })
    + ' ' +
    d.toLocaleTimeString('id-ID',{ hour: '2-digit', minute: '2-digit' })
}

function statusClass(s) {
  if (s === 'accepted') return 'bg-success'
  if (s === 'declined') return 'bg-danger'
  return 'bg-warning text-dark'
}

async function accept() {
  await api.updateExchangeStatus(request.value.id, 'accepted')
  request.value.status = 'accepted'
}

async function decline() {
  await api.updateExchangeStatus(request.value.id, 'declined')
  request.value.status = 'declined'
}

function goBack() {
  router.back()
}

onMounted(async () => {
  const id = Number(route.params.id)
  try {
    // fetch incoming and outgoing, find matching request
    const [{ data: rec }, { data: sent }] = await Promise.all([
      api.getReceivedExchanges(),
      api.getMyExchangeRequests()
    ])
    const all = [...rec.exchanges, ...sent.exchanges]
    const found = all.find(e => e.id === id)
    if (!found) {
      return router.replace('/exchange/requests')
    }
    // normalize coverUrl fields
    found.bookRequested.coverUrl = found.bookRequested.imageUrl
    found.bookOffered.coverUrl   = found.offeredBook.imageUrl
    request.value = {
      id:            found.id,
      sender:        (found.requester || found.owner),
      bookRequested: { ...found.requestedBook, coverUrl: found.requestedBook.imageUrl },
      bookOffered:   { ...found.offeredBook,   coverUrl: found.offeredBook.imageUrl },
      message:       found.messages || '',
      method:        found.location ? 'meet' : 'delivery',
      location:      found.location || found.address || '',
      date:          found.meetingDatetime?.slice(0,10) || '',
      time:          found.meetingDatetime?.slice(11,16) || '',
      created_at:    found.createdAt,
      status:        found.status
    }
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <Navbar/>

  <Breadcrumb :items="[
    { text: 'Home', to: '/' },
    { text: 'Requests', to: '/exchange/requests' },
    { text: 'Detail Request', active: true }
  ]"/>

  <div class="main-content py-4">
    <button class="btn btn-link mb-3" @click="goBack">
      ← Kembali
    </button>

    <div v-if="loading" class="text-center py-5">
      <div class="spinner-border text-primary" role="status"></div>
    </div>

    <div v-else-if="request">
      <h1 class="mb-4">Detail Request Penukaran</h1>

      <!-- Pengirim & Status -->
      <div class="row align-items-center mb-4">
        <div class="col-auto text-center">
          <img
            :src="request.sender.avatarUrl || defaultAvatar"
            class="rounded-circle"
            width="80" height="80"
          />
          <p class="mt-2 mb-0"><strong>{{ request.sender.name }}</strong></p>
          <small class="text-muted">{{ request.sender.email }}</small>
        </div>
        <div class="col">
          <p class="mb-1">Dikirim pada: {{ formatDate(request.created_at) }}</p>
          <span class="badge" :class="statusClass(request.status)">
            {{ request.status }}
          </span>
        </div>
      </div>

      <!-- Buku Diminta -->
      <h5>Buku Diminta</h5>
      <div class="card mb-3 p-3">
        <div class="row g-3 align-items-center">
          <div class="col-auto">
            <img
              :src="request.bookRequested.coverUrl || defaultCover"
              alt="Cover Requested"
              class="img-fluid rounded"
              width="100"
            />
          </div>
          <div class="col">
            <h6 class="mb-1">{{ request.bookRequested.title }}</h6>
            <p class="text-muted mb-0">by {{ request.bookRequested.author }}</p>
          </div>
        </div>
      </div>

      <!-- Buku Ditawarkan -->
      <h5>Buku Ditawarkan</h5>
      <div class="card mb-3 p-3">
        <div class="row g-3 align-items-center">
          <div class="col-auto">
            <img
              :src="request.bookOffered.coverUrl || defaultCover"
              alt="Cover Offered"
              class="img-fluid rounded"
              width="100"
            />
          </div>
          <div class="col">
            <h6 class="mb-1">{{ request.bookOffered.title }}</h6>
            <p class="text-muted mb-0">by {{ request.bookOffered.author }}</p>
          </div>
        </div>
      </div>

      <!-- Pesan -->
      <h5>Pesan</h5>
      <p class="mb-4">{{ request.message }}</p>

      <!-- Metode & Jadwal -->
      <h5>Detail Pertukaran</h5>
      <p class="mb-1">
        <strong>Metode:</strong>
        {{ request.method === 'meet' ? 'Ketemuan' : 'Kirim Kurir' }}
      </p>
      <p class="mb-1">
        <strong>{{ request.method === 'meet' ? 'Lokasi' : 'Alamat' }}:</strong>
        {{ request.location }}
      </p>
      <p class="mb-4">
        <strong>Waktu:</strong> {{ request.date }} {{ request.time }}
      </p>

      <!-- Aksi -->
      <div v-if="request.status === 'pending'" class="mb-5">
        <button class="btn btn-success me-2" @click="accept">Terima</button>
        <button class="btn btn-danger" @click="decline">Tolak</button>
      </div>
    </div>

    <div v-else class="text-center text-muted py-5">
      Request tidak ditemukan.
    </div>
  </div>
</template>

<style scoped>
/* beri jarak default */
.main-content { padding-bottom: 2rem; }
</style>

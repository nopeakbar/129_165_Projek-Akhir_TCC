<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import Navbar     from '@/components/layouts/Navbar.vue'
import Breadcrumb from '@/components/commons/Breadcrumb.vue'
import api        from '@/services/api.js'

const router = useRouter()

// form state
const form = reactive({
  title: '',
  author: '',
  genre: '',
  condition: 'Low',
  coverUrl: ''
})

// validation
const errors = reactive({ title: '', author: '' })
function validate() {
  let ok = true
  errors.title  = ''
  errors.author = ''
  if (!form.title.trim()) {
    errors.title = 'Judul buku wajib diisi.'
    ok = false
  }
  if (!form.author.trim()) {
    errors.author = 'Nama penulis wajib diisi.'
    ok = false
  }
  return ok
}

// submit
async function onSubmit() {
  if (!validate()) return
  try {
    await api.createBook({ ...form })
    alert(`Buku "${form.title}" berhasil diposting!`)
    router.push({ name: 'books' })
  } catch (err) {
    console.error(err)
    alert(err.response?.data?.message || 'Gagal posting buku.')
  }
}
</script>

<template>
  <Navbar/>
  <div class="main-content py-4">
    <Breadcrumb :items="[
      { text: 'Books', to: '/books' },
      { text: 'Post Books', to: '/books/new', active: true }
    ]"/>
    <h1 class="mb-4">Posting Buku Baru</h1>
    <div class="card px-4 py-3">
      <form @submit.prevent="onSubmit">
        <!-- Judul -->
        <div class="mb-3">
          <label class="form-label">Judul Buku</label>
          <input
            v-model="form.title"
            type="text"
            class="form-control"
            :class="{ 'is-invalid': errors.title }"
            placeholder="Masukkan judul buku"
          />
          <div class="invalid-feedback">{{ errors.title }}</div>
        </div>
        <!-- Penulis -->
        <div class="mb-3">
          <label class="form-label">Penulis</label>
          <input
            v-model="form.author"
            type="text"
            class="form-control"
            :class="{ 'is-invalid': errors.author }"
            placeholder="Masukkan nama penulis"
          />
          <div class="invalid-feedback">{{ errors.author }}</div>
        </div>
        <!-- Genre -->
        <div class="mb-3">
          <label class="form-label">Genre</label>
          <input
            v-model="form.genre"
            type="text"
            class="form-control"
            placeholder="Misal: Novel, Programming"
          />
        </div>
        <!-- Kondisi -->
        <div class="mb-3">
          <label class="form-label">Kondisi</label>
          <select v-model="form.condition" class="form-select">
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </div>
        <!-- Cover URL -->
        <div class="mb-4">
          <label class="form-label">Cover URL</label>
          <input
            v-model="form.coverUrl"
            type="url"
            class="form-control"
            placeholder="https://..."
          />
        </div>
        <!-- Buttons -->
        <button type="submit" class="btn btn-success me-2">Posting Buku</button>
        <router-link to="/books" class="btn btn-secondary">Batal</router-link>
      </form>
    </div>
  </div>
</template>

<style scoped>
/* nothing special */
</style>

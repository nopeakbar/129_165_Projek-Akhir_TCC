<!-- src/components/cards/BookCard.vue -->
<script setup>
import { defineProps, defineEmits } from 'vue'

const props = defineProps({
  book: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['exchange'])

const defaultCover = 'https://via.placeholder.com/150x200?text=No+Cover'

function onExchange(e) {
  // mencegah klik pada tombol memicu navigasi ke detail
  e.stopPropagation()
  emit('exchange', props.book)
}
</script>

<template>
  <router-link
    :to="{ name: 'books-detail', params: { id: book.id } }"
    class="card h-100 shadow-sm text-decoration-none text-reset"
  >
    <!-- Cover Buku -->
    <img
      :src="book.coverUrl || defaultCover"
      alt="Cover Buku"
      class="card-img-top"
    />

    <div class="card-body d-flex flex-column">
      <!-- Judul & Penulis -->
      <h5 class="card-title">{{ book.title }}</h5>
      <p class="card-text text-muted mb-1">{{ book.author }}</p>

      <!-- Genre -->
      <p v-if="book.genre" class="card-text mb-3">
        <small class="text-secondary">{{ book.genre }}</small>
      </p>

      <!-- Tombol Tukar di pojok bawah -->
      <div class="mt-auto">
        <button
          @click.stop="onExchange"
          class="btn btn-outline-primary btn-sm"
        >
          <i class="bi bi-arrow-left-right me-1"></i>
          Tukar
        </button>
      </div>
    </div>
  </router-link>
</template>

<style scoped>
.card-img-top {
  height: 180px;
  object-fit: cover;
}
</style>

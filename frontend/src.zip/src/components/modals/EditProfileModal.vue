<script setup>
import { reactive, toRefs, watch } from 'vue'
import { defineProps, defineEmits } from 'vue'

const props = defineProps({
  show: { type: Boolean, required: true },
  user: {
    type: Object,
    required: true,
    // { id, name, email, avatarUrl }
  }
})

const emit = defineEmits(['close', 'save'])

// Salin props.user ke form lokal agar tidak langsung mutasi
const form = reactive({
  name: '',
  email: '',
  avatarUrl: ''
})

// sync ketika props.user atau show berubah
watch(
  () => props.show,
  (val) => {
    if (val) {
      form.name = props.user.name
      form.email = props.user.email
      form.avatarUrl = props.user.avatarUrl
    }
  }
)

// Validasi sederhana
const errors = reactive({
  name: '',
  email: ''
})

function validate() {
  errors.name = form.name.trim() ? '' : 'Nama wajib diisi'
  errors.email = /\S+@\S+\.\S+/.test(form.email)
    ? ''
    : 'Email tidak valid'
  return !errors.name && !errors.email
}

function onSave() {
  if (!validate()) return
  // kirim data ke parent
  emit('save', { ...form })
}

function onClose() {
  emit('close')
}
</script>

<template>
  <!-- Backdrop -->
  <div
    v-if="show"
    class="modal-backdrop fade show"
    @click="onClose"
  ></div>

  <!-- Modal -->
  <div
    v-if="show"
    class="modal fade show d-block"
    tabindex="-1"
    aria-modal="true"
    role="dialog"
  >
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Profil</h5>
          <button
            type="button"
            class="btn-close"
            aria-label="Close"
            @click="onClose"
          ></button>
        </div>
        <div class="modal-body">
          <form @submit.prevent="onSave">
            <!-- Nama -->
            <div class="mb-3">
              <label class="form-label">Nama Lengkap</label>
              <input
                v-model="form.name"
                type="text"
                class="form-control"
                :class="{ 'is-invalid': errors.name }"
              />
              <div class="invalid-feedback">{{ errors.name }}</div>
            </div>

            <!-- Email -->
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input
                v-model="form.email"
                type="email"
                class="form-control"
                :class="{ 'is-invalid': errors.email }"
              />
              <div class="invalid-feedback">{{ errors.email }}</div>
            </div>

            <!-- Avatar URL -->
            <div class="mb-3">
              <label class="form-label">Avatar URL</label>
              <input
                v-model="form.avatarUrl"
                type="url"
                class="form-control"
                placeholder="https://..."
              />
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button
            type="button"
            class="btn btn-secondary"
            @click="onClose"
          >
            Batal
          </button>
          <button
            type="button"
            class="btn btn-primary"
            @click="onSave"
          >
            Simpan
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* Pastikan modal tampil di atas konten */
.modal {
  background: transparent;
}
.modal-dialog {
  max-width: 500px;
}
/* Hilangkan scroll di belakang */
body.modal-open {
  overflow: hidden;
}
</style>
// src/services/api.js
import axios from 'axios'

const API_URL = 'http://localhost:5000/api'

const apiInstance = axios.create({
  baseURL: API_URL,
  withCredentials: true,
})

// set token jika ada
const token = localStorage.getItem('accessToken')
if (token) apiInstance.defaults.headers.common.Authorization = `Bearer ${token}`

// interceptor refresh
apiInstance.interceptors.response.use(
  r => r,
  async err => {
    if (err.response?.status === 401) {
      try {
        const { data } = await axios.get(`${API_URL}/token/refresh`, { withCredentials: true })
        localStorage.setItem('accessToken', data.accessToken)
        apiInstance.defaults.headers.common.Authorization = `Bearer ${data.accessToken}`
        err.config.headers.Authorization = `Bearer ${data.accessToken}`
        return apiInstance(err.config)
      } catch {
        localStorage.removeItem('accessToken')
        window.location.href = '/login'
      }
    }
    return Promise.reject(err)
  }
)

export default {
  // ── Auth ─────────────────────────────────────────────────
  register: u => apiInstance.post('/auth/register', u),
  login: u => apiInstance.post('/auth/login', u)
    .then(r => {
      const t = r.data.accessToken || r.data.token
      localStorage.setItem('accessToken', t)
      apiInstance.defaults.headers.common.Authorization = `Bearer ${t}`
      return r
    }),
  logout: () => apiInstance.post('/auth/logout')
    .then(r => {
      localStorage.removeItem('accessToken')
      delete apiInstance.defaults.headers.common.Authorization
      window.location.href = '/login'
      return r
    }),

  // ── Profile ───────────────────────────────────────────────
  getProfile:    () => apiInstance.get('/users/profile'),
  updateProfile: d => apiInstance.put('/users/profile/update', d),
  changePassword:(oldP,newP) => apiInstance.put('/users/profile/change-password',{ oldPassword: oldP, newPassword: newP }),

  // ── Users (admin) ────────────────────────────────────────
  getUsers:     () => apiInstance.get('/users'),
  getUserById:  id => apiInstance.get(`/users/${id}`),
  createUser:   d  => apiInstance.post('/users', d),
  updateUser:   (id,d) => apiInstance.put(`/users/${id}`, d),
  deleteUser:   id => apiInstance.delete(`/users/${id}`),

  // ── Books ────────────────────────────────────────────────
  addBook:      b  => apiInstance.post('/books', b),
  getAllBooks:  async () => {
    const r = await apiInstance.get('/books')
    return { books: r.data.data }
  },
  getMyBooks:   async () => {
    const r = await apiInstance.get('/books/me')
    return { books: r.data.data }
  },
  getBookDetail: async id => {
    const r = await apiInstance.get(`/books/${id}`)
    return { book: r.data.data }
  },
  updateBook:   (id,d) => apiInstance.put(`/books/${id}`, d),
  deleteBook:   id => apiInstance.delete(`/books/${id}`),

  // ── Exchanges ────────────────────────────────────────────
  requestExchange:        p => apiInstance.post('/exchanges', p),
  getReceivedExchanges:   async () => {
    const r = await apiInstance.get('/exchanges/received')
    return { exchanges: r.data.data }
  },
  getMyExchangeRequests: async () => {
    const r = await apiInstance.get('/exchanges/sent')
    return { exchanges: r.data.data }
  },
  updateExchangeStatus:   (id,s) => apiInstance.put(`/exchanges/${id}`, { status: s }),

  // ── Exchange History ─────────────────────────────────────
  addExchangeHistory:     p => apiInstance.post('/exchanges/history', p),
  getAllExchangeHistory:  async () => {
    const r = await apiInstance.get('/exchanges/history')
    return { histories: r.data.data }
  },
  getExchangeHistoryById: async id => {
    const r = await apiInstance.get(`/exchanges/history/${id}`)
    return { history: r.data.data }
  },
}
